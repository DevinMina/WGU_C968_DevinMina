﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevinMina_C968
{
    public class InHouse : Part
    {
        private int machineID;
        public int MachineID { get; set; }


        //Default Constructor
        public InHouse() { }


        //Constructor
        public InHouse(int partID, string name, int inStock, decimal price, int min, int max, int machineID)
        {
            this.PartID = partID;
            this.Name = name;
            this.InStock = inStock;
            this.Price = price;
            this.Min = min;
            this.Max = max;
            this.MachineID = machineID;
        }
    }
}