﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DevinMina_C968
{
    public class Inventory
    {
        //Binding Lists - Products & Parts
        public static BindingList<Part> Parts = new BindingList<Part>();
        public static BindingList<Product> Products = new BindingList<Product>();


        //Create Dummy Parts & Products
        static Inventory()
        {
            //Random Number Generator 
            var rnd = new Random();

            //Create Dummy Parts
            //Columns: ID, Name, Price, InStock, Min, Max
            Part part1 = new InHouse(rnd.Next(10000, 99999), "Part 1", 15, 2.5m, 5, 20, 001);
            Part part2 = new InHouse(rnd.Next(10000, 99999), "Part 2", 13, 4.45m, 2, 15, 002);
            Part part3 = new Outsourced(rnd.Next(10000, 99999), "Part 3", 3, 6.75m, 1, 10, "Company Inc.");
            Part part4 = new Outsourced(rnd.Next(10000, 99999), "Part 4", 5, 10.25m, 3, 18, "Example Co.");

            Parts.Add(part1);
            Parts.Add(part2);
            Parts.Add(part3);
            Parts.Add(part4);


            //Create Dummy Products
            Product product1 = new Product(rnd.Next(10000, 99999), "Product 1", 8, 10.40m, 2, 15);
            Product product2 = new Product(rnd.Next(10000, 99999), "Product 2", 6, 11.45m, 5, 15);
            Product product3 = new Product(rnd.Next(10000, 99999), "Product 3", 10, 7.55m, 5, 13);
            Product product4 = new Product(rnd.Next(10000, 99999), "Product 4", 12, 6.85m, 4, 18);

            Products.Add(product1);
            Products.Add(product2);
            Products.Add(product3);
            Products.Add(product4);

            //Attach associated parts
            product1.AssociatedParts.Add(part1);
            product2.AssociatedParts.Add(part2);
            product3.AssociatedParts.Add(part3);
            product4.AssociatedParts.Add(part4);
        }


        //Add Part Method
        public static void AddPart(Part part)
        {
            Parts.Add(part);
        }

        //Delete Part Method 
        public static bool DeletePart(Part partID)
        {
            foreach (Part part in Parts)
            {
                if (part != partID)
                {
                    continue;
                }

                Parts.Remove(part);
                return true;
            }
            return false;
        }

        //Lookup Part Method
        public static Part LookupPart(int partID)
        {
            foreach (Part part in Parts)
            {
                if (part.PartID == partID)
                {
                    return part;
                }
                else
                {
                    MessageBox.Show("Part ID does not exist. \n Please try again.");
                }
            }

            return null;
        }

        //Update Part Method
        public static void UpdatePart(int partID, Part part)
        {
            LookupPart(partID);
            DeletePart(part);
            AddPart(part);
        }


        //Add Product Method
        public static void AddProduct(Product product)
        {
            Products.Add(product);
        }


        //Remove Product Method
        public static bool RemoveProduct(int productID)
        {
            foreach (Product product in Products)
            {
                if (product.ProductID != productID)
                {
                    continue;
                }

                Products.Remove(product);
                return true;
            }

            return false;
        }


        //Lookup Product Method
        public static Product LookupProduct(int productID)
        {
            foreach (Product product in Products)
            {
                if (product.ProductID == productID)
                {
                    return product;
                }
            }

            Product nullProduct = new DevinMina_C968.Product();
            return nullProduct;
        }

        //Update Product Method
        public static void UpdateProduct(int productID, Product product)
        {
            LookupProduct(productID);
            RemoveProduct(productID);
            AddProduct(product);
        }
    }
}
