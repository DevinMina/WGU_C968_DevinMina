﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DevinMina_C968
{
    public class Product
    {
        //Binding List - Associated Parts
        public BindingList<Part> AssociatedParts = new BindingList<Part>();

        private int productID;
        private string name;
        private int inStock;
        private decimal price;
        private int min;
        private int max;

        //Getters & Setters
        public int ProductID { get; set; }
        public string Name { get; set; }
        public int InStock { get; set; }
        public decimal Price { get; set; }
        public int Min { get; set; }
        public int Max { get; set; }


        //Default Constructor
        public Product() { }

        //Constructor
        public Product(int productId, string name, int inStock, decimal price, int min, int max)
        {
            this.ProductID = productId;
            this.Name = name;
            this.InStock = inStock;
            this.Price = price;
            this.Min = min;
            this.Max = max;
        }


        //Add Associated Part
        public void AddAssociatedPart(Part part)
        {
            AssociatedParts.Add(part);
        }


        //Delete Part from Associate Parts List
        public bool RemoveAssociatedPart(int partID)
        {
            var removed = false;
            foreach (Part part in AssociatedParts)
            {
                if (partID != part.PartID)
                {
                    continue;
                }

                AssociatedParts.Remove(part);
                return true;
            }

            return removed;
        }


        //Lookup Associated Part
        public Part LookupAssociatedPart(int partID)
        {
            foreach (Part part in AssociatedParts)
            {
                if (partID == part.PartID)
                {
                    return part;
                }
            }

            return null;
        }
    }
}
