﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevinMina_C968
{
    public class Outsourced : Part
    {
        private string companyName;
        public string CompanyName { get; set; }


        //Default Constructor
        public Outsourced() { }


        //Constructor
        public Outsourced(int partID, string name, int inStock, decimal price, int min, int max, string companyName)
        {
            this.PartID = partID;
            this.Name = name;
            this.Price = price;
            this.InStock = inStock;
            this.Min = min;
            this.Max = max;
            this.CompanyName = companyName;
        }
    }
}
