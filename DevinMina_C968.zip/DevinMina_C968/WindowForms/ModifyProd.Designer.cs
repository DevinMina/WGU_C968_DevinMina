﻿
namespace DevinMina_C968.WindowForms
{
    partial class ModifyProd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tbIDNum = new System.Windows.Forms.TextBox();
            this.tbMin = new System.Windows.Forms.TextBox();
            this.tbName = new System.Windows.Forms.TextBox();
            this.tbInv = new System.Windows.Forms.TextBox();
            this.tbMax = new System.Windows.Forms.TextBox();
            this.tbPriceCost = new System.Windows.Forms.TextBox();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.labelPriceCost = new System.Windows.Forms.Label();
            this.labelInv = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelID = new System.Windows.Forms.Label();
            this.modProdTitle = new System.Windows.Forms.Label();
            this.dgvModAssociatedParts = new System.Windows.Forms.DataGridView();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.sbParts = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.dgvModParts = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSearch = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvModAssociatedParts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvModParts)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbIDNum
            // 
            this.tbIDNum.AutoSize = true;
            this.tbIDNum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tbIDNum.Cursor = System.Windows.Forms.Cursors.No;
            this.tbIDNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIDNum.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tbIDNum.Location = new System.Drawing.Point(121, 152);
            this.tbIDNum.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.tbIDNum.Name = "tbIDNum";
            this.tbIDNum.Size = new System.Drawing.Size(137, 20);
            this.tbIDNum.TabIndex = 56;
            this.tbIDNum.Text = "Loading ID Number";
            // 
            // tbMin
            // 
            this.tbMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMin.ForeColor = System.Drawing.Color.DimGray;
            this.tbMin.Location = new System.Drawing.Point(200, 342);
            this.tbMin.Name = "tbMin";
            this.tbMin.Size = new System.Drawing.Size(55, 24);
            this.tbMin.TabIndex = 68;
            this.tbMin.Text = "Min";
            // 
            // tbName
            // 
            this.tbName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbName.ForeColor = System.Drawing.Color.DimGray;
            this.tbName.Location = new System.Drawing.Point(121, 199);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(135, 24);
            this.tbName.TabIndex = 64;
            this.tbName.Text = "Product Name";
            // 
            // tbInv
            // 
            this.tbInv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbInv.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbInv.ForeColor = System.Drawing.Color.DimGray;
            this.tbInv.Location = new System.Drawing.Point(121, 240);
            this.tbInv.Name = "tbInv";
            this.tbInv.Size = new System.Drawing.Size(134, 24);
            this.tbInv.TabIndex = 65;
            this.tbInv.Text = "Inv";
            // 
            // tbMax
            // 
            this.tbMax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMax.ForeColor = System.Drawing.Color.DimGray;
            this.tbMax.Location = new System.Drawing.Point(69, 342);
            this.tbMax.Name = "tbMax";
            this.tbMax.Size = new System.Drawing.Size(56, 24);
            this.tbMax.TabIndex = 67;
            this.tbMax.Text = "Max";
            // 
            // tbPriceCost
            // 
            this.tbPriceCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbPriceCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPriceCost.ForeColor = System.Drawing.Color.DimGray;
            this.tbPriceCost.Location = new System.Drawing.Point(121, 288);
            this.tbPriceCost.Name = "tbPriceCost";
            this.tbPriceCost.Size = new System.Drawing.Size(135, 24);
            this.tbPriceCost.TabIndex = 66;
            this.tbPriceCost.Text = "Price/Cost";
            // 
            // labelMin
            // 
            this.labelMin.AutoSize = true;
            this.labelMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMin.Location = new System.Drawing.Point(163, 354);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(32, 18);
            this.labelMin.TabIndex = 63;
            this.labelMin.Text = "Min";
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMax.Location = new System.Drawing.Point(18, 344);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(36, 18);
            this.labelMax.TabIndex = 62;
            this.labelMax.Text = "Max";
            // 
            // labelPriceCost
            // 
            this.labelPriceCost.AutoSize = true;
            this.labelPriceCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPriceCost.Location = new System.Drawing.Point(18, 290);
            this.labelPriceCost.Name = "labelPriceCost";
            this.labelPriceCost.Size = new System.Drawing.Size(78, 18);
            this.labelPriceCost.TabIndex = 61;
            this.labelPriceCost.Text = "Price/Cost";
            // 
            // labelInv
            // 
            this.labelInv.AutoSize = true;
            this.labelInv.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInv.Location = new System.Drawing.Point(18, 242);
            this.labelInv.Name = "labelInv";
            this.labelInv.Size = new System.Drawing.Size(26, 18);
            this.labelInv.TabIndex = 60;
            this.labelInv.Text = "Inv";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.Location = new System.Drawing.Point(18, 199);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(48, 18);
            this.labelName.TabIndex = 59;
            this.labelName.Text = "Name";
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelID.Location = new System.Drawing.Point(18, 152);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(22, 18);
            this.labelID.TabIndex = 58;
            this.labelID.Text = "ID";
            // 
            // modProdTitle
            // 
            this.modProdTitle.AutoSize = true;
            this.modProdTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modProdTitle.Location = new System.Drawing.Point(12, 95);
            this.modProdTitle.Name = "modProdTitle";
            this.modProdTitle.Size = new System.Drawing.Size(171, 26);
            this.modProdTitle.TabIndex = 57;
            this.modProdTitle.Text = "Modify Product";
            // 
            // dgvModAssociatedParts
            // 
            this.dgvModAssociatedParts.AllowUserToAddRows = false;
            this.dgvModAssociatedParts.AllowUserToOrderColumns = true;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvModAssociatedParts.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle17;
            this.dgvModAssociatedParts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvModAssociatedParts.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvModAssociatedParts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dgvModAssociatedParts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvModAssociatedParts.Location = new System.Drawing.Point(3, 3);
            this.dgvModAssociatedParts.MultiSelect = false;
            this.dgvModAssociatedParts.Name = "dgvModAssociatedParts";
            this.dgvModAssociatedParts.ReadOnly = true;
            this.dgvModAssociatedParts.RowHeadersWidth = 60;
            this.dgvModAssociatedParts.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvModAssociatedParts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvModAssociatedParts.Size = new System.Drawing.Size(488, 165);
            this.dgvModAssociatedParts.TabIndex = 0;
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnDelete.Location = new System.Drawing.Point(720, 483);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(60, 28);
            this.btnDelete.TabIndex = 74;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnAdd.Location = new System.Drawing.Point(724, 241);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(60, 28);
            this.btnAdd.TabIndex = 73;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // sbParts
            // 
            this.sbParts.Location = new System.Drawing.Point(601, 35);
            this.sbParts.Margin = new System.Windows.Forms.Padding(2);
            this.sbParts.Name = "sbParts";
            this.sbParts.Size = new System.Drawing.Size(179, 20);
            this.sbParts.TabIndex = 69;
            this.sbParts.TabStop = false;
            this.sbParts.Text = "Enter Part ID";
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(724, 568);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(60, 28);
            this.btnSave.TabIndex = 71;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(633, 568);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(64, 28);
            this.btnCancel.TabIndex = 70;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // dgvModParts
            // 
            this.dgvModParts.AllowUserToAddRows = false;
            this.dgvModParts.AllowUserToOrderColumns = true;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvModParts.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle19;
            this.dgvModParts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvModParts.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvModParts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.dgvModParts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvModParts.Location = new System.Drawing.Point(3, 3);
            this.dgvModParts.MultiSelect = false;
            this.dgvModParts.Name = "dgvModParts";
            this.dgvModParts.ReadOnly = true;
            this.dgvModParts.RowHeadersWidth = 60;
            this.dgvModParts.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvModParts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvModParts.Size = new System.Drawing.Size(488, 165);
            this.dgvModParts.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.dgvModAssociatedParts);
            this.panel2.Location = new System.Drawing.Point(288, 303);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(496, 175);
            this.panel2.TabIndex = 76;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.dgvModParts);
            this.panel1.Location = new System.Drawing.Point(288, 61);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(496, 175);
            this.panel1.TabIndex = 75;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(520, 35);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(66, 21);
            this.btnSearch.TabIndex = 72;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // ModifyProd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1235, 774);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.sbParts);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.tbIDNum);
            this.Controls.Add(this.tbMin);
            this.Controls.Add(this.tbName);
            this.Controls.Add(this.tbInv);
            this.Controls.Add(this.tbMax);
            this.Controls.Add(this.tbPriceCost);
            this.Controls.Add(this.labelMin);
            this.Controls.Add(this.labelMax);
            this.Controls.Add(this.labelPriceCost);
            this.Controls.Add(this.labelInv);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.labelID);
            this.Controls.Add(this.modProdTitle);
            this.Name = "ModifyProd";
            this.Text = "ModifyProd";
            ((System.ComponentModel.ISupportInitialize)(this.dgvModAssociatedParts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvModParts)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbIDNum;
        private System.Windows.Forms.TextBox tbMin;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.TextBox tbInv;
        private System.Windows.Forms.TextBox tbMax;
        private System.Windows.Forms.TextBox tbPriceCost;
        private System.Windows.Forms.Label labelMin;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.Label labelPriceCost;
        private System.Windows.Forms.Label labelInv;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.Label modProdTitle;
        private System.Windows.Forms.DataGridView dgvModAssociatedParts;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox sbParts;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DataGridView dgvModParts;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSearch;
    }
}