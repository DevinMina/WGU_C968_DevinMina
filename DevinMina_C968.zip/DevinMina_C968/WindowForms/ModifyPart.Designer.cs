﻿
namespace DevinMina_C968
{
    partial class ModifyPart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbPartID = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.tbMin = new System.Windows.Forms.TextBox();
            this.radBtnInHouse = new System.Windows.Forms.RadioButton();
            this.tbMachID_CompNm = new System.Windows.Forms.TextBox();
            this.tbName = new System.Windows.Forms.TextBox();
            this.tbInv = new System.Windows.Forms.TextBox();
            this.tbMax = new System.Windows.Forms.TextBox();
            this.tbPriceCost = new System.Windows.Forms.TextBox();
            this.labelCompanyName = new System.Windows.Forms.Label();
            this.labelMin = new System.Windows.Forms.Label();
            this.labelMax = new System.Windows.Forms.Label();
            this.labelPriceCost = new System.Windows.Forms.Label();
            this.labelInv = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelID = new System.Windows.Forms.Label();
            this.radBtnOutsourced = new System.Windows.Forms.RadioButton();
            this.titleAddPart = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbPartID
            // 
            this.tbPartID.AutoSize = true;
            this.tbPartID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tbPartID.Cursor = System.Windows.Forms.Cursors.No;
            this.tbPartID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPartID.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tbPartID.Location = new System.Drawing.Point(141, 63);
            this.tbPartID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.tbPartID.Name = "tbPartID";
            this.tbPartID.Size = new System.Drawing.Size(137, 20);
            this.tbPartID.TabIndex = 32;
            this.tbPartID.Text = "Loading ID Number";
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(397, 332);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(60, 28);
            this.btnSave.TabIndex = 31;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(305, 332);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(64, 28);
            this.btnCancel.TabIndex = 30;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // tbMin
            // 
            this.tbMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMin.ForeColor = System.Drawing.Color.DimGray;
            this.tbMin.Location = new System.Drawing.Point(339, 249);
            this.tbMin.Name = "tbMin";
            this.tbMin.Size = new System.Drawing.Size(118, 24);
            this.tbMin.TabIndex = 24;
            this.tbMin.Text = "Min";
            this.tbMin.Enter += new System.EventHandler(this.tbMin_Enter);
            this.tbMin.Leave += new System.EventHandler(this.tbMin_Leave);
            // 
            // radBtnInHouse
            // 
            this.radBtnInHouse.AutoSize = true;
            this.radBtnInHouse.Checked = true;
            this.radBtnInHouse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radBtnInHouse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radBtnInHouse.Location = new System.Drawing.Point(160, 10);
            this.radBtnInHouse.Name = "radBtnInHouse";
            this.radBtnInHouse.Size = new System.Drawing.Size(93, 24);
            this.radBtnInHouse.TabIndex = 15;
            this.radBtnInHouse.TabStop = true;
            this.radBtnInHouse.Text = "In-House";
            this.radBtnInHouse.UseVisualStyleBackColor = true;
            this.radBtnInHouse.CheckedChanged += new System.EventHandler(this.radBtnInHouse_CheckedChanged);
            // 
            // tbMachID_CompNm
            // 
            this.tbMachID_CompNm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMachID_CompNm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMachID_CompNm.ForeColor = System.Drawing.Color.DimGray;
            this.tbMachID_CompNm.Location = new System.Drawing.Point(141, 301);
            this.tbMachID_CompNm.Name = "tbMachID_CompNm";
            this.tbMachID_CompNm.Size = new System.Drawing.Size(129, 24);
            this.tbMachID_CompNm.TabIndex = 27;
            this.tbMachID_CompNm.Text = "Machine ID";
            this.tbMachID_CompNm.Enter += new System.EventHandler(this.tbMachID_CompNm_Enter);
            this.tbMachID_CompNm.Leave += new System.EventHandler(this.tbMachID_CompNm_Leave);
            // 
            // tbName
            // 
            this.tbName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbName.ForeColor = System.Drawing.Color.DimGray;
            this.tbName.Location = new System.Drawing.Point(141, 112);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(129, 24);
            this.tbName.TabIndex = 17;
            this.tbName.Text = "Part Name";
            this.tbName.Enter += new System.EventHandler(this.tbName_Enter);
            this.tbName.Leave += new System.EventHandler(this.tbName_Leave);
            // 
            // tbInv
            // 
            this.tbInv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbInv.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbInv.ForeColor = System.Drawing.Color.DimGray;
            this.tbInv.Location = new System.Drawing.Point(141, 153);
            this.tbInv.Name = "tbInv";
            this.tbInv.Size = new System.Drawing.Size(129, 24);
            this.tbInv.TabIndex = 19;
            this.tbInv.Text = "Inv";
            this.tbInv.Enter += new System.EventHandler(this.tbInv_Enter);
            this.tbInv.Leave += new System.EventHandler(this.tbInv_Leave);
            // 
            // tbMax
            // 
            this.tbMax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMax.ForeColor = System.Drawing.Color.DimGray;
            this.tbMax.Location = new System.Drawing.Point(141, 248);
            this.tbMax.Name = "tbMax";
            this.tbMax.Size = new System.Drawing.Size(129, 24);
            this.tbMax.TabIndex = 22;
            this.tbMax.Text = "Max";
            this.tbMax.Enter += new System.EventHandler(this.tbMax_Enter);
            this.tbMax.Leave += new System.EventHandler(this.tbMax_Leave);
            // 
            // tbPriceCost
            // 
            this.tbPriceCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbPriceCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPriceCost.ForeColor = System.Drawing.Color.DimGray;
            this.tbPriceCost.Location = new System.Drawing.Point(141, 202);
            this.tbPriceCost.Name = "tbPriceCost";
            this.tbPriceCost.Size = new System.Drawing.Size(129, 24);
            this.tbPriceCost.TabIndex = 21;
            this.tbPriceCost.Text = "Price/Cost";
            this.tbPriceCost.Enter += new System.EventHandler(this.tbPriceCost_Enter);
            this.tbPriceCost.Leave += new System.EventHandler(this.tbPriceCost_Leave);
            // 
            // labelCompanyName
            // 
            this.labelCompanyName.AutoSize = true;
            this.labelCompanyName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCompanyName.Location = new System.Drawing.Point(16, 304);
            this.labelCompanyName.Name = "labelCompanyName";
            this.labelCompanyName.Size = new System.Drawing.Size(82, 18);
            this.labelCompanyName.TabIndex = 29;
            this.labelCompanyName.Text = "Machine ID";
            // 
            // labelMin
            // 
            this.labelMin.AutoSize = true;
            this.labelMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMin.Location = new System.Drawing.Point(302, 251);
            this.labelMin.Name = "labelMin";
            this.labelMin.Size = new System.Drawing.Size(32, 18);
            this.labelMin.TabIndex = 28;
            this.labelMin.Text = "Min";
            // 
            // labelMax
            // 
            this.labelMax.AutoSize = true;
            this.labelMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMax.Location = new System.Drawing.Point(16, 251);
            this.labelMax.Name = "labelMax";
            this.labelMax.Size = new System.Drawing.Size(36, 18);
            this.labelMax.TabIndex = 26;
            this.labelMax.Text = "Max";
            // 
            // labelPriceCost
            // 
            this.labelPriceCost.AutoSize = true;
            this.labelPriceCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPriceCost.Location = new System.Drawing.Point(16, 202);
            this.labelPriceCost.Name = "labelPriceCost";
            this.labelPriceCost.Size = new System.Drawing.Size(78, 18);
            this.labelPriceCost.TabIndex = 25;
            this.labelPriceCost.Text = "Price/Cost";
            // 
            // labelInv
            // 
            this.labelInv.AutoSize = true;
            this.labelInv.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInv.Location = new System.Drawing.Point(16, 154);
            this.labelInv.Name = "labelInv";
            this.labelInv.Size = new System.Drawing.Size(26, 18);
            this.labelInv.TabIndex = 23;
            this.labelInv.Text = "Inv";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.Location = new System.Drawing.Point(16, 112);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(48, 18);
            this.labelName.TabIndex = 20;
            this.labelName.Text = "Name";
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelID.Location = new System.Drawing.Point(22, 65);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(22, 18);
            this.labelID.TabIndex = 18;
            this.labelID.Text = "ID";
            // 
            // radBtnOutsourced
            // 
            this.radBtnOutsourced.AutoSize = true;
            this.radBtnOutsourced.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radBtnOutsourced.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radBtnOutsourced.Location = new System.Drawing.Point(281, 10);
            this.radBtnOutsourced.Name = "radBtnOutsourced";
            this.radBtnOutsourced.Size = new System.Drawing.Size(110, 24);
            this.radBtnOutsourced.TabIndex = 16;
            this.radBtnOutsourced.TabStop = true;
            this.radBtnOutsourced.Text = "Outsourced";
            this.radBtnOutsourced.UseVisualStyleBackColor = true;
            this.radBtnOutsourced.CheckedChanged += new System.EventHandler(this.radBtnOutsourced_CheckedChanged);
            // 
            // titleAddPart
            // 
            this.titleAddPart.AutoSize = true;
            this.titleAddPart.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleAddPart.Location = new System.Drawing.Point(10, 7);
            this.titleAddPart.Name = "titleAddPart";
            this.titleAddPart.Size = new System.Drawing.Size(133, 26);
            this.titleAddPart.TabIndex = 14;
            this.titleAddPart.Text = "Modify Part";
            // 
            // ModifyPart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(488, 384);
            this.Controls.Add(this.tbPartID);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.tbMin);
            this.Controls.Add(this.radBtnInHouse);
            this.Controls.Add(this.tbMachID_CompNm);
            this.Controls.Add(this.tbName);
            this.Controls.Add(this.tbInv);
            this.Controls.Add(this.tbMax);
            this.Controls.Add(this.tbPriceCost);
            this.Controls.Add(this.labelCompanyName);
            this.Controls.Add(this.labelMin);
            this.Controls.Add(this.labelMax);
            this.Controls.Add(this.labelPriceCost);
            this.Controls.Add(this.labelInv);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.labelID);
            this.Controls.Add(this.radBtnOutsourced);
            this.Controls.Add(this.titleAddPart);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximumSize = new System.Drawing.Size(504, 423);
            this.MinimumSize = new System.Drawing.Size(504, 423);
            this.Name = "ModifyPart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "PartModify";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label tbPartID;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox tbMin;
        private System.Windows.Forms.RadioButton radBtnInHouse;
        private System.Windows.Forms.TextBox tbMachID_CompNm;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.TextBox tbInv;
        private System.Windows.Forms.TextBox tbMax;
        private System.Windows.Forms.TextBox tbPriceCost;
        private System.Windows.Forms.Label labelCompanyName;
        private System.Windows.Forms.Label labelMin;
        private System.Windows.Forms.Label labelMax;
        private System.Windows.Forms.Label labelPriceCost;
        private System.Windows.Forms.Label labelInv;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.RadioButton radBtnOutsourced;
        private System.Windows.Forms.Label titleAddPart;
    }
}