﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DevinMina_C968
{
    public partial class AddProduct : Form
    {
        public BindingList<Part> tempAssociatedParts = new BindingList<Part>();

        public AddProduct()
        {
            InitializeComponent();
            AddProductFormLoad();
            //dgvAssociatedParts_DataBindingComplete();

            //Set The Data Sources
            //dgvParts.DataSource = Inventory.Parts;
            //dgvAssociatedParts.DataSource = Product.AssociatedParts;

            //Full Row Selection
            //dgvParts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //dgvAssociatedParts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            ////Make Grid Read Only
            //dgvParts.ReadOnly = true;
            //dgvAssociatedParts.ReadOnly = true;

            ////Make Grid Single Select
            //dgvParts.MultiSelect = false;
            //dgvAssociatedParts.MultiSelect = false;

            ////Remove Empty Bottom Row
            //dgvParts.AllowUserToAddRows = false;
            //dgvAssociatedParts.AllowUserToAddRows = false;

            //Renaming Column Headers For Parts List
            //dgvParts.Columns["PartID"].HeaderText = "Part ID";
            //dgvParts.Columns["Name"].HeaderText = "Part Name";
            //dgvParts.Columns["InStock"].HeaderText = "Inventory Level";
            //dgvParts.Columns["Price"].DefaultCellStyle.Format = "c2";
            //dgvParts.Columns["Price"].HeaderText = "Price/Cost per Unit";
            //dgvParts.Columns["Min"].Visible = false;
            //dgvParts.Columns["Max"].Visible = false;


            //Rename Column Headers For Associated Parts List
            //dgvAssociatedParts.Columns["PartID"].HeaderText = "Part ID";
            //dgvAssociatedParts.Columns["Name"].HeaderText = "Part Name";
            //dgvAssociatedParts.Columns["InStock"].HeaderText = "Inventory Level";
            //dgvAssociatedParts.Columns["Price"].DefaultCellStyle.Format = "c2";
            //dgvAssociatedParts.Columns["Price"].HeaderText = "Price/Cost per Unit";
            //dgvAssociatedParts.Columns["Min"].Visible = false;
            //dgvAssociatedParts.Columns["Max"].Visible = false;
        }


        public void AddProductFormLoad()
        {
            var addPartLoad = new BindingSource();
            addPartLoad.DataSource = Inventory.Parts;
            dgvParts.DataSource = addPartLoad;
            dgvParts.Columns["PartID"].HeaderText = "Part ID";
            dgvParts.Columns["Name"].HeaderText = "Part Name";
            dgvParts.Columns["InStock"].HeaderText = "Inventory Level";
            dgvParts.Columns["Price"].DefaultCellStyle.Format = "c2";
            dgvParts.Columns["Price"].HeaderText = "Price/Cost per Unit";
            dgvParts.Columns["Min"].Visible = false;
            dgvParts.Columns["Max"].Visible = false;


            var assocPartLoad = new BindingSource();
            assocPartLoad.DataSource = tempAssociatedParts;
            dgvAssociatedParts.DataSource = assocPartLoad;
            dgvAssociatedParts.Columns["PartID"].HeaderText = "Part ID";
            dgvAssociatedParts.Columns["Name"].HeaderText = "Part Name";
            dgvAssociatedParts.Columns["InStock"].HeaderText = "Inventory Level";
            dgvAssociatedParts.Columns["Price"].DefaultCellStyle.Format = "c2";
            dgvAssociatedParts.Columns["Price"].HeaderText = "Price/Cost per Unit";
            dgvAssociatedParts.Columns["Min"].Visible = false;
            dgvAssociatedParts.Columns["Max"].Visible = false;
        }


        private void dgvParts_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dgvParts.ClearSelection();
        }

        private void dgvAssociatedParts_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dgvAssociatedParts.ClearSelection();
        }

        //Product Name Enter/Leave
        private void tbName_Enter(object sender, EventArgs e)
        {
            if (tbName.Text.Contains("Product Name"))
            {
                tbName.Text = "";
                tbName.ForeColor = Color.Black;
            }
        }

        private void tbName_Leave(object sender, EventArgs e)
        {
            if (tbName.Text == "")
            {
                tbName.Text = "Product Name";
                tbName.ForeColor = Color.DimGray;
            }
        }


        //Product Inv Enter/Leave
        private void tbInv_Enter(object sender, EventArgs e)
        {
            if (tbInv.Text.Contains("Inv"))
            {
                tbInv.Text = "";
                tbInv.ForeColor = Color.Black;
            }
        }

        private void tbInv_Leave(object sender, EventArgs e)
        {
            if (tbInv.Text == "")
            {
                tbInv.Text = "Inv";
                tbInv.ForeColor = Color.DimGray;
            }
        }


        //Product Price/Cost Enter/Leave
        private void tbPriceCost_Enter(object sender, EventArgs e)
        {
            if (tbPriceCost.Text.Contains("Price/Cost"))
            {
                tbPriceCost.Text = "";
                tbPriceCost.ForeColor = Color.Black;
            }
        }

        private void tbPriceCost_Leave(object sender, EventArgs e)
        {
            if (tbPriceCost.Text == "")
            {
                tbPriceCost.Text = "Price/Cost";
                tbPriceCost.ForeColor = Color.DimGray;
            }
        }


        //Product Max Enter/Leave
        private void tbMax_Enter(object sender, EventArgs e)
        {
            if (tbMax.Text.Contains("Max"))
            {
                tbMax.Text = "";
                tbMax.ForeColor = Color.Black;
            }
        }

        private void tbMax_Leave(object sender, EventArgs e)
        {
            if (tbMax.Text == "")
            {
                tbMax.Text = "Max";
                tbMax.ForeColor = Color.DimGray;
            }
        }


        //Product Min Enter/Leave
        private void tbMin_Enter(object sender, EventArgs e)
        {
            if (tbMin.Text.Contains("Min"))
            {
                tbMin.Text = "";
                tbMin.ForeColor = Color.Black;
            }
        }

        private void tbMin_Leave(object sender, EventArgs e)
        {
            if (tbMin.Text == "")
            {
                tbMin.Text = "Min";
                tbMin.ForeColor = Color.DimGray;
            }
        }


        //If user types in search and hits enter after the part will be searched instead of clicking search
        private void sbParts_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)

            {
                btnSearch_Click(this, new EventArgs());

                e.SuppressKeyPress = true;
            }
        }


        //Search Part Button
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                int searchIDValue = int.Parse(sbParts.Text);
                var idFound = false;
                foreach (DataGridViewRow partID in dgvParts.Rows)
                {
                    if (partID.Cells[0].Value.Equals(searchIDValue))
                    {
                        dgvParts.CurrentCell = dgvParts.Rows[partID.Index].Cells[0];
                        idFound = true;
                        break;
                    }
                }

                if (idFound == false)
                {
                    MessageBox.Show("Error: Part ID number was not found.");
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error: Please enter a numeric value EX: 18504");
            }
        }

        //SearchBox Enter/Leave 
        private void sbParts_Enter(object sender, EventArgs e)
        {
            if (sbParts.Text.Contains("Enter Part ID"))
            {
                sbParts.Text = "";
                sbParts.ForeColor = Color.Black;
            }
        }

        private void sbParts_Leave(object sender, EventArgs e)
        {
            if (sbParts.Text == "")
            {
                sbParts.Text = "Enter Part ID";
                sbParts.ForeColor = Color.DimGray;
            }
        }

        //Add Part to Associate Part Button
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (dgvParts.CurrentRow == null || !dgvParts.CurrentRow.Selected)
            {
                MessageBox.Show("Error: You must select a part to add.");
            }
            else
            {
                var associatedPart = dgvParts.CurrentRow.DataBoundItem;
                var result = MessageBox.Show("Are you sure you want to add this part?",
                    "Confirmation", MessageBoxButtons.YesNo);

                if (result == DialogResult.No)
                {
                    return;
                }

                if (result == DialogResult.Yes)
                {
                    var addingAssociatedPart = (Part)dgvParts.CurrentRow.DataBoundItem;
                    tempAssociatedParts.Add(addingAssociatedPart);
                }
            }
        }


        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvAssociatedParts.CurrentRow == null || !dgvAssociatedParts.CurrentRow.Selected)
            {
                MessageBox.Show("Error: You must select a part to delete.");
            }
            else
            {
               // Part deletingPart = dgvAssociatedParts.CurrentRow.DataBoundItem as Part;
                var result = MessageBox.Show("Are you sure you want to delete this part? This cannot be undone.",
                    "Confirmation", MessageBoxButtons.YesNo);

                if (result == DialogResult.No)
                {
                    return;
                }

                if (result == DialogResult.Yes)
                {
                    Part deletingPart = dgvAssociatedParts.CurrentRow.DataBoundItem as Part;
                    foreach (DataGridViewRow part in dgvAssociatedParts.SelectedRows)
                    {
                        dgvAssociatedParts.Rows.RemoveAt(part.Index);
                    }

                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //Display error message when defaults are unused by the user
            //Comp Name goes back to "Comp Name" when clicking save and displays an error when a new string is entered
            if (tbName.Text.Contains("Part Name") || tbInv.Text.Contains("Inv") ||
                tbPriceCost.Text.Contains("Price/Cost") ||
                tbMax.Text.Contains("Max") || tbMin.Text.Contains("Min"))

            {
                MessageBox.Show("Error: One or more field values are missing. Please try again.");
                return;
            }

            //Random Number Generator 
            var rnd = new Random();
            var num = rnd.Next(10000, 99999);


            //Initial Variables
            var name = tbName.Text;
            int inStock;
            decimal price;
            int max;
            int min;
            int n;
            decimal x;

            //Try Variables
            var isInv = int.TryParse(tbInv.Text, out n);
            var isPrice = decimal.TryParse(tbPriceCost.Text, out x);
            var isMax = int.TryParse(tbMax.Text, out n);
            var isMin = int.TryParse(tbMin.Text, out n);
            ;

            if (isInv == true)
            {
                inStock = int.Parse(tbInv.Text);
            }
            else
            {
                MessageBox.Show("Error: Inventory value must be a numeric value.");
                return;
            }

            if (isPrice == true)
            {
                price = decimal.Parse(tbPriceCost.Text);
            }
            else
            {
                MessageBox.Show("Error: Price/Cost value must be a numeric value.");
                return;
            }

            if (isMax == true)
            {
                max = int.Parse(tbMax.Text);
            }
            else
            {
                MessageBox.Show("Error: Max value must be a numeric value.");
                return;
            }

            if (isMin == true)
            {
                min = int.Parse(tbMin.Text);
            }
            else
            {
                MessageBox.Show("Error: Min value must be a numeric value.");
                return;
            }


            if (max < min)
            {
                MessageBox.Show("Error: Maximum value cannot be less than the minimum value.");
                return;
            }

            if (min <= 0)
            {
                MessageBox.Show("Error: Minimum value cannot be less than or equal to zero.");
                return;
            }

            if (inStock > max || inStock < min)
            {
                MessageBox.Show(
                    "Error: Inventory must be between the minimum and maximum amount of inventory.");
                return;
            }

            //Add exception if there's an empty associated parts table then throw message and return
            //if (dgvAssociatedParts.RowCount == 0)
            //{
            //    MessageBox.Show("Error: You must add a part to be associated with this product.");
            //    return;
            //}

            Product newProduct =
                new Product(num, name, inStock, price, min, max);
            Inventory.AddProduct(newProduct);

            foreach (Part part in tempAssociatedParts)
            {
                //newProduct.AddAssociatedPart(part);
                newProduct.AddAssociatedPart(part);
            }

            this.Close();
        }


        //Cancel Button
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}