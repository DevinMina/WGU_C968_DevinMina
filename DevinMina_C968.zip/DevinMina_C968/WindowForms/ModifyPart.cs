﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DevinMina_C968
{
    public partial class ModifyPart : Form
    {
        //Default Constructor
        public ModifyPart()
        {
            InitializeComponent();
        }

        //Constructor InHouse
        public ModifyPart(InHouse inHousePart)
        {
            ModifyPart modifyPart = new ModifyPart();

            modifyPart.radBtnOutsourced.Checked = false;
            modifyPart.radBtnInHouse.Checked = true;
            modifyPart.tbPartID.Text = inHousePart.PartID.ToString();
            modifyPart.tbName.Text = inHousePart.Name;
            modifyPart.tbInv.Text = inHousePart.InStock.ToString();
            modifyPart.tbPriceCost.Text = inHousePart.Price.ToString();
            modifyPart.tbMax.Text = inHousePart.Max.ToString();
            modifyPart.tbMin.Text = inHousePart.Min.ToString();
            modifyPart.tbMachID_CompNm.Text = inHousePart.MachineID.ToString();


            //Change Default Text Color
            modifyPart.tbPartID.ForeColor = Color.Black;
            modifyPart.tbName.ForeColor = Color.Black;
            modifyPart.tbInv.ForeColor = Color.Black;
            modifyPart.tbPriceCost.ForeColor = Color.Black;
            modifyPart.tbMax.ForeColor = Color.Black;
            modifyPart.tbMin.ForeColor = Color.Black;
            modifyPart.tbMachID_CompNm.ForeColor = Color.Black;

            modifyPart.Show();
        }

        //Constructor Outsourced
        public ModifyPart(Outsourced outsourcedPart)
        {
            ModifyPart modifyPart = new ModifyPart();

            modifyPart.radBtnInHouse.Checked = false;
            modifyPart.radBtnOutsourced.Checked = true;
            modifyPart.tbPartID.Text = outsourcedPart.PartID.ToString();
            modifyPart.tbName.Text = outsourcedPart.Name;
            modifyPart.tbInv.Text = outsourcedPart.InStock.ToString();
            modifyPart.tbPriceCost.Text = outsourcedPart.Price.ToString();
            modifyPart.tbMax.Text = outsourcedPart.Max.ToString();
            modifyPart.tbMin.Text = outsourcedPart.Min.ToString();
            modifyPart.tbMachID_CompNm.Text = outsourcedPart.CompanyName;


            //Change Default Text Color
            modifyPart.tbPartID.ForeColor = Color.Black;
            modifyPart.tbName.ForeColor = Color.Black;
            modifyPart.tbInv.ForeColor = Color.Black;
            modifyPart.tbPriceCost.ForeColor = Color.Black;
            modifyPart.tbMax.ForeColor = Color.Black;
            modifyPart.tbMin.ForeColor = Color.Black;
            modifyPart.tbMachID_CompNm.ForeColor = Color.Black;

            modifyPart.Show();
        }


        //In-House Radio
        private void radBtnInHouse_CheckedChanged(object sender, EventArgs e)
        {
            labelCompanyName.Text = "Machine ID";
            if (radBtnInHouse.Checked)
            {
                tbMachID_CompNm.Text = "Machine ID";
                tbMachID_CompNm.ForeColor = Color.DimGray;
            }
        }

        //Outsourced Radio
        private void radBtnOutsourced_CheckedChanged(object sender, EventArgs e)
        {
            labelCompanyName.Text = "Company Name";
            if (radBtnOutsourced.Checked)
            {
                tbMachID_CompNm.Text = "Comp Name";
                tbMachID_CompNm.ForeColor = Color.DimGray;
            }
        }

        //Name TextBox - Enter/Leave
        private void tbName_Enter(object sender, EventArgs e)
        {
            if (tbName.Text.Contains("Part Name"))
            {
                tbName.Text = "";
                tbName.ForeColor = Color.Black;
            }
        }

        private void tbName_Leave(object sender, EventArgs e)
        {
            if (tbName.Text == "")
            {
                tbName.Text = "Part Name";
                tbName.ForeColor = Color.DimGray;
            }
        }

        //Inv TextBox - Enter/Leave
        private void tbInv_Enter(object sender, EventArgs e)
        {
            if (tbInv.Text.Contains("Inv"))
            {
                tbInv.Text = "";
                tbInv.ForeColor = Color.Black;
            }
        }

        private void tbInv_Leave(object sender, EventArgs e)
        {
            if (tbInv.Text == "")
            {
                tbInv.Text = "Inv";
                tbInv.ForeColor = Color.DimGray;
            }
        }

        //Price/Cost TextBox - Enter/Leave
        private void tbPriceCost_Enter(object sender, EventArgs e)
        {
            if (tbPriceCost.Text.Contains("Price/Cost"))
            {
                tbPriceCost.Text = "";
                tbPriceCost.ForeColor = Color.Black;
            }
        }

        private void tbPriceCost_Leave(object sender, EventArgs e)
        {
            if (tbPriceCost.Text == "")
            {
                tbPriceCost.Text = "Price/Cost";
                tbPriceCost.ForeColor = Color.DimGray;
            }
        }

        //Max TextBox - Enter/Leave
        private void tbMax_Enter(object sender, EventArgs e)
        {
            if (tbMax.Text.Contains("Max"))
            {
                tbMax.Text = "";
                tbMax.ForeColor = Color.Black;
            }
        }

        private void tbMax_Leave(object sender, EventArgs e)
        {
            if (tbMax.Text == "")
            {
                tbMax.Text = "Max";
                tbMax.ForeColor = Color.DimGray;
            }
        }

        //Min TextBox - Enter/Leave
        private void tbMin_Enter(object sender, EventArgs e)
        {
            if (tbMin.Text.Contains("Min"))
            {
                tbMin.Text = "";
                tbMin.ForeColor = Color.Black;
            }
        }

        private void tbMin_Leave(object sender, EventArgs e)
        {
            if (tbMin.Text == "")
            {
                tbMin.Text = "Min";
                tbMin.ForeColor = Color.DimGray;
            }
        }

        //CompName_&_MachineID TextBox - Enter/Leave
        private void tbMachID_CompNm_Enter(object sender, EventArgs e)
        {
            if (radBtnInHouse.Checked)
            {
                if (tbMachID_CompNm.Text.Contains("Machine ID") || tbMachID_CompNm.Text.Contains("Comp Name"))
                {
                    tbMachID_CompNm.Text = "";
                    tbMachID_CompNm.ForeColor = Color.Black;
                }
            }
            else if (radBtnOutsourced.Checked)
            {
                if (tbMachID_CompNm.Text.Contains("Comp Name"))
                {
                    tbMachID_CompNm.Text = "";
                    tbMachID_CompNm.ForeColor = Color.Black;
                }
            }
        }

        private void tbMachID_CompNm_Leave(object sender, EventArgs e)
        {
            if (radBtnInHouse.Checked)
            {
                if (tbMachID_CompNm.Text == "")
                {
                    tbMachID_CompNm.Text = "Machine ID";
                    tbMachID_CompNm.ForeColor = Color.DimGray;
                }
            }
            else if (radBtnOutsourced.Checked)
            {
                if (tbMachID_CompNm.Text == "")
                {
                    tbMachID_CompNm.Text = "Comp Name";
                    tbMachID_CompNm.ForeColor = Color.DimGray;
                }
            }
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            if (tbName.Text.Contains("Part Name") || tbInv.Text.Contains("Inv") ||
                tbPriceCost.Text.Contains("Price/Cost") ||
                tbMax.Text.Contains("Max") || tbMin.Text.Contains("Min") ||
                tbMachID_CompNm.Text.Contains("Machine ID, Comp Name") ||
                tbMachID_CompNm.Text.Contains("Machine ID") ||
                (radBtnOutsourced.Checked && tbMachID_CompNm.Text == "Comp Name"))

            {
                MessageBox.Show("Error: One or more field values are missing. Please try again.");
                return;
            }


            //Initial Variables
            var partID = int.Parse(tbPartID.Text);
            var name = tbName.Text;
            int inStock;
            decimal price;
            int max;
            int min;
            int machineID;
            var compName = tbMachID_CompNm.Text;
            int n;
            decimal x;

            //Try Variables
            var isInv = int.TryParse(tbInv.Text, out n);
            var isPrice = decimal.TryParse(tbPriceCost.Text, out x);
            var isMax = int.TryParse(tbMax.Text, out n);
            var isMin = int.TryParse(tbMin.Text, out n);
            var isMac = int.TryParse(tbMachID_CompNm.Text, out n);

            if (isInv == true)
            {
                inStock = int.Parse(tbInv.Text);
            }
            else
            {
                MessageBox.Show("Error: Inventory value must be a numeric value.");
                return;
            }

            if (isPrice == true)
            {
                price = decimal.Parse(tbPriceCost.Text);
            }
            else
            {
                MessageBox.Show("Error: Price/Cost value must be a numeric value.");
                return;
            }

            if (isMax == true)
            {
                max = int.Parse(tbMax.Text);
            }
            else
            {
                MessageBox.Show("Error: Max value must be a numeric value.");
                return;
            }

            if (isMin == true)
            {
                min = int.Parse(tbMin.Text);
            }
            else
            {
                MessageBox.Show("Error: Min value must be a numeric value.");
                return;
            }

            if (max < min)
            {
                MessageBox.Show("Error: Maximum value cannot be less than the minimum value.");
                return;
            }

            if (min <= 0)
            {
                MessageBox.Show("Error: Minimum value cannot be less than or equal to zero.");
                return;
            }

            if (inStock > max || inStock < min)
            {
                MessageBox.Show(
                    "Error: Inventory must be between the minimum and maximum levels of inventory.");
                return;
            }


            if (radBtnInHouse.Checked)
            {
                if (isMac == true)
                {
                    machineID = int.Parse(tbMachID_CompNm.Text);
                }
                else
                {
                    MessageBox.Show("Error: Machine ID value must be a numeric value.");
                    return;
                }

                InHouse inHousePart = new InHouse(partID, name, inStock, price, min, max, machineID);
                for (int i = 0; i < Inventory.Parts.Count; i++)
                {
                    if (Inventory.Parts[i].PartID == inHousePart.PartID)
                    {
                        Inventory.DeletePart(Inventory.Parts[i]);
                        Inventory.AddPart(inHousePart);
                        this.Close();
                    }
                }
            }

            if (radBtnOutsourced.Checked)
            {
                string companyName = tbMachID_CompNm.Text;
                Outsourced outsourcedPart = new Outsourced(partID, name, inStock, price, min, max, companyName);
                for (int i = 0; i < Inventory.Parts.Count; i++)
                {
                    if (Inventory.Parts[i].PartID == outsourcedPart.PartID)
                    {
                        Inventory.DeletePart(Inventory.Parts[i]);
                        Inventory.AddPart(outsourcedPart);
                        this.Close();
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}