﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevinMina_C968.WindowForms;

namespace DevinMina_C968
{
    public partial class InventoryManagementSystem : Form
    {
        public InventoryManagementSystem()
        {
            InitializeComponent();

            //Set The Data Source
            dgvParts.DataSource = Inventory.Parts;
            dgvProducts.DataSource = Inventory.Products;

            //Full Row Selection
            dgvParts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvProducts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            //Make Grid Read Only
            dgvParts.ReadOnly = true;
            dgvProducts.ReadOnly = true;

            //Make Grid Single Select
            dgvParts.MultiSelect = false;
            dgvProducts.MultiSelect = false;

            //Remove Empty Bottom Row
            dgvParts.AllowUserToAddRows = false;
            dgvProducts.AllowUserToAddRows = false;


            //Renaming Columns For Parts List
            dgvParts.Columns["PartID"].HeaderText = "Part ID";
            dgvParts.Columns["Name"].HeaderText = "Part Name";
            dgvParts.Columns["InStock"].HeaderText = "Inventory Level";
            dgvParts.Columns["Price"].DefaultCellStyle.Format = "c2";
            dgvParts.Columns["Price"].HeaderText = "Price/Cost per Unit";
            dgvParts.Columns["Min"].Visible = false;
            dgvParts.Columns["Max"].Visible = false;


            //Renaming Columns For Products List
            dgvProducts.Columns["ProductID"].HeaderText = "Product ID";
            dgvProducts.Columns["Name"].HeaderText = "Product Name";
            dgvProducts.Columns["InStock"].HeaderText = "Inventory Level";
            dgvProducts.Columns["Price"].DefaultCellStyle.Format = "c2";
            dgvProducts.Columns["Price"].HeaderText = "Price per Unit";
            dgvProducts.Columns["Min"].Visible = false;
            dgvProducts.Columns["Max"].Visible = false;
        }

        private void partsBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dgvParts.ClearSelection();
        }

        private void productsBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dgvProducts.ClearSelection();
        }

        //Add Part Button
        private void btnAddPart_Click(object sender, EventArgs e)
        {
            new AddPart().ShowDialog();
        }

        //Modify Part Button
        private void btnModifyPart_Click(object sender, EventArgs e)
        {
            //Check For No Selection
            if (dgvParts.CurrentRow == null || !dgvParts.CurrentRow.Selected)
            {
                MessageBox.Show("Nothing is selected! \n Please make a selction.");
                return;
            }

            if (dgvParts.CurrentRow.DataBoundItem is InHouse)
            {
                InHouse inHousePartSelected = dgvParts.CurrentRow.DataBoundItem as InHouse;
                ModifyPart modifyPartWindow = new ModifyPart(inHousePartSelected);
            }
            else if (dgvParts.CurrentRow.DataBoundItem is Outsourced)
            {
                Outsourced outsourcedPartSelected = dgvParts.CurrentRow.DataBoundItem as Outsourced;
                ModifyPart modifyPartWindow = new ModifyPart(outsourcedPartSelected);
            }
            else
            {
                return;
            }
        }

        //Delete Part Button
        private void btnDeletePart_Click(object sender, EventArgs e)
        {
            if (dgvParts.CurrentRow == null || !dgvParts.CurrentRow.Selected)
            {
                MessageBox.Show("Error: You must select a part to delete.");
            }
            else
            {
                Part deletingPart = dgvParts.CurrentRow.DataBoundItem as Part;
                var result = MessageBox.Show("Are you sure you want to delete this part? This cannot be undone...",
                    "Confirmation", MessageBoxButtons.YesNo);

                if (result == DialogResult.No)
                {
                    return;
                }

                if (result == DialogResult.Yes)
                {
                    Inventory.DeletePart(deletingPart);
                }
            }
        }

        //Allows the user to search the part by hitting enter
        private void sbParts_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)

            {
                btnPartSearch_Click(this, new EventArgs());

                e.SuppressKeyPress = true;
            }
        }


        //Part Search Button
        private void btnPartSearch_Click(object sender, EventArgs e)
        {
            try
            {
                int searchIDValue = int.Parse(sbParts.Text);
                var idFound = false;
                foreach (DataGridViewRow partID in dgvParts.Rows)
                {
                    if (partID.Cells[0].Value.Equals(searchIDValue))
                    {
                        //Used to test -> MessageBox.Show("idFound is true!");
                        dgvParts.CurrentCell = dgvParts.Rows[partID.Index].Cells[0];
                        //User to verify part ID was found -> MessageBox.Show(string.Format("Part ID: {0} Found.", sbParts.Text));
                        idFound = true;
                        break;
                    }
                }

                if (idFound == false)
                {
                    MessageBox.Show("Error: Part ID number was not found.");
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error: Please enter a numeric value EX: 18504");
            }
        }

        //SearchBox Enter/Leave 
        private void sbParts_Enter(object sender, EventArgs e)
        {
            if (sbParts.Text.Contains("Enter Part ID"))
            {
                sbParts.Text = "";
                sbParts.ForeColor = Color.Black;
            }
        }

        private void sbParts_Leave(object sender, EventArgs e)
        {
            if (sbParts.Text == "")
            {
                sbParts.Text = "Enter Part ID";
                sbParts.ForeColor = Color.DimGray;
            }
        }


        //Add Product Button
        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            new AddProduct().ShowDialog();
        }

        private void btnModifyProduct_Click(object sender, EventArgs e)
        {
            //Check For No Selection
            if (dgvProducts.CurrentRow == null || !dgvProducts.CurrentRow.Selected)
            {
                MessageBox.Show("Nothing is selected! \n Please make a selction.");
                return;
            }

            if (dgvProducts.CurrentRow.DataBoundItem is Product)
            {
                Product productSelected = dgvProducts.CurrentRow.DataBoundItem as Product;
                new ModifyProd(productSelected).ShowDialog();
            }
            else
            {
                return;
            }
        }


        //Delete Product Button
        private void btnDeleteProduct_Click(object sender, EventArgs e)
        {
            if (dgvProducts.CurrentRow == null || !dgvProducts.CurrentRow.Selected)
            {
                MessageBox.Show("Error: You must select a product to delete.");
            }
            else
            {
                Product deletingProduct = dgvProducts.CurrentRow.DataBoundItem as Product;
                var result = MessageBox.Show("Are you sure you want to delete this product? This cannot be undone.",
                    "Confirmation", MessageBoxButtons.YesNo);

                if (result == DialogResult.No)
                {
                    return;
                }

                if (result == DialogResult.Yes)
                {
                    if (deletingProduct.AssociatedParts.Count > 0)
                    {
                        MessageBox.Show("Error: cannot delete a product that has parts associated with it.");
                        return;
                    }

                    Inventory.RemoveProduct(deletingProduct.ProductID);
                }
            }
        }

        //Allows the user to hit enter after typing in a productID# to search
        private void sbProducts_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)

            {
                btnProductSearch_Click(this, new EventArgs());

                e.SuppressKeyPress = true;
            }
        }

        //Product Search Button
        private void btnProductSearch_Click(object sender, EventArgs e)
        {
            try
            {
                int searchIDValue = int.Parse(sbProducts.Text);
                var idFound = false;
                foreach (DataGridViewRow productID in dgvProducts.Rows)
                {
                    if (productID.Cells[0].Value.Equals(searchIDValue))
                    {
                        //Used to test -> MessageBox.Show("idFound is true!");
                        dgvProducts.CurrentCell = dgvProducts.Rows[productID.Index].Cells[0];
                        MessageBox.Show(string.Format("Product ID: {0} Found.", sbProducts.Text));
                        idFound = true;
                        break;
                    }
                }

                if (idFound == false)
                {
                    MessageBox.Show("Error: Product ID number was not found.");
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error: Please enter a numeric value. EX: 18504");
            }
        }

        //SearchBox Enter/Leave 
        private void sbProducts_Enter(object sender, EventArgs e)
        {
            if (sbProducts.Text.Contains("Enter Product ID"))
            {
                sbProducts.Text = "";
                sbProducts.ForeColor = Color.Black;
            }
        }

        private void sbProducts_Leave(object sender, EventArgs e)
        {
            if (sbProducts.Text == "")
            {
                sbProducts.Text = "Enter Product ID";
                sbProducts.ForeColor = Color.DimGray;
            }
        }

        //Exit Application Button
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}