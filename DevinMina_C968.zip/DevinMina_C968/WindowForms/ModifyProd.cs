﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DevinMina_C968.WindowForms
{
    public partial class ModifyProd : Form
    {
        BindingList<Part> tempAssociatedParts = new BindingList<Part>();

        InventoryManagementSystem inventoryManagementSystem =
            (InventoryManagementSystem)Application.OpenForms["InvMgmtSyst"];

        public ModifyProd(Product product)
        {
            InitializeComponent();
            ModifyProductFormLoad(product);
        }

        //Modify Product Constructor
        public void ModifyProductFormLoad(Product product)
        {
            tbIDNum.Text = product.ProductID.ToString();
            tbName.Text = product.Name;
            tbInv.Text = product.InStock.ToString();
            tbPriceCost.Text = product.Price.ToString();
            tbMax.Text = product.Max.ToString();
            tbMin.Text = product.Min.ToString();


            //Change Default Text Color
            tbIDNum.ForeColor = Color.Black;
            tbName.ForeColor = Color.Black;
            tbInv.ForeColor = Color.Black;
            tbPriceCost.ForeColor = Color.Black;
            tbMax.ForeColor = Color.Black;
            tbMin.ForeColor = Color.Black;


            //BindingSource
            var modPartLoad = new BindingSource();
            modPartLoad.DataSource = Inventory.Parts;
            dgvModParts.DataSource = modPartLoad;

            //Renaming Column Headers For Parts List
            dgvModParts.Columns["PartID"].HeaderText = "Part ID";
            dgvModParts.Columns["Name"].HeaderText = "Part Name";
            dgvModParts.Columns["InStock"].HeaderText = "Inventory Level";
            dgvModParts.Columns["Price"].DefaultCellStyle.Format = "c2";
            dgvModParts.Columns["Price"].HeaderText = "Price/Cost per Unit";
            dgvModParts.Columns["Min"].Visible = false;
            dgvModParts.Columns["Max"].Visible = false;


            foreach (Part part in product.AssociatedParts)
            {
                tempAssociatedParts.Add(part);
            }

            var assocPartLoad = new BindingSource();
            assocPartLoad.DataSource = tempAssociatedParts;
            dgvModAssociatedParts.DataSource = assocPartLoad;

            ////Rename Column Headers For Associated Parts List
            dgvModAssociatedParts.Columns["PartID"].HeaderText = "Part ID";
            dgvModAssociatedParts.Columns["Name"].HeaderText = "Part Name";
            dgvModAssociatedParts.Columns["InStock"].HeaderText = "Inventory Level";
            dgvModAssociatedParts.Columns["Price"].DefaultCellStyle.Format = "c2";
            dgvModAssociatedParts.Columns["Price"].HeaderText = "Price/Cost per Unit";
            dgvModAssociatedParts.Columns["Min"].Visible = false;
            dgvModAssociatedParts.Columns["Max"].Visible = false;
        }


        private void dgvParts_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dgvModParts.ClearSelection();
        }

        private void dgvAssociatedParts_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dgvModAssociatedParts.ClearSelection();
        }


        //Product Name Enter/Leave
        private void tbName_Enter(object sender, EventArgs e)
        {
            if (tbName.Text.Contains("Product Name"))
            {
                tbName.Text = "";
                tbName.ForeColor = Color.Black;
            }
        }

        private void tbName_Leave(object sender, EventArgs e)
        {
            if (tbName.Text == "")
            {
                tbName.Text = "Product Name";
                tbName.ForeColor = Color.DimGray;
            }
        }


        //Product Inv Enter/Leave
        private void tbInv_Enter(object sender, EventArgs e)
        {
            if (tbInv.Text.Contains("Inv"))
            {
                tbInv.Text = "";
                tbInv.ForeColor = Color.Black;
            }
        }

        private void tbInv_Leave(object sender, EventArgs e)
        {
            if (tbInv.Text == "")
            {
                tbInv.Text = "Inv";
                tbInv.ForeColor = Color.DimGray;
            }
        }


        //Product Price/Cost Enter/Leave
        private void tbPriceCost_Enter(object sender, EventArgs e)
        {
            if (tbPriceCost.Text.Contains("Price/Cost"))
            {
                tbPriceCost.Text = "";
                tbPriceCost.ForeColor = Color.Black;
            }
        }

        private void tbPriceCost_Leave(object sender, EventArgs e)
        {
            if (tbPriceCost.Text == "")
            {
                tbPriceCost.Text = "Price/Cost";
                tbPriceCost.ForeColor = Color.DimGray;
            }
        }


        //Product Max Enter/Leave
        private void tbMax_Enter(object sender, EventArgs e)
        {
            if (tbMax.Text.Contains("Max"))
            {
                tbMax.Text = "";
                tbMax.ForeColor = Color.Black;
            }
        }

        private void tbMax_Leave(object sender, EventArgs e)
        {
            if (tbMax.Text == "")
            {
                tbMax.Text = "Max";
                tbMax.ForeColor = Color.DimGray;
            }
        }


        //Product Min Enter/Leave
        private void tbMin_Enter(object sender, EventArgs e)
        {
            if (tbMin.Text.Contains("Min"))
            {
                tbMin.Text = "";
                tbMin.ForeColor = Color.Black;
            }
        }

        private void tbMin_Leave(object sender, EventArgs e)
        {
            if (tbMin.Text == "")
            {
                tbMin.Text = "Min";
                tbMin.ForeColor = Color.DimGray;
            }
        }


        //Search Part Button
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                int searchIDValue = int.Parse(sbParts.Text);
                var idFound = false;
                foreach (DataGridViewRow partID in dgvModParts.Rows)
                {
                    if (partID.Cells[0].Value.Equals(searchIDValue))
                    {
                        dgvModParts.CurrentCell = dgvModParts.Rows[partID.Index].Cells[0];
                        idFound = true;
                        break;
                    }
                }

                if (idFound == false)
                {
                    MessageBox.Show("Error: Part ID number was not found.");
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error: Please enter a numeric value EX: 18504");
            }
        }

        //SearchBox Enter/Leave 
        private void sbParts_Enter(object sender, EventArgs e)
        {
            if (sbParts.Text.Contains("Enter Part ID"))
            {
                sbParts.Text = "";
                sbParts.ForeColor = Color.Black;
            }
        }

        private void sbParts_Leave(object sender, EventArgs e)
        {
            if (sbParts.Text == "")
            {
                sbParts.Text = "Enter Part ID";
                sbParts.ForeColor = Color.DimGray;
            }
        }


        //Add Part to Associate Part Button
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (dgvModParts.CurrentRow == null || !dgvModParts.CurrentRow.Selected)
            {
                MessageBox.Show("Error: You must select a part to add to this product.");
            }
            else
            {
                var result = MessageBox.Show("Are you sure you want to add the selected part to this product?",
                    "Confirmation", MessageBoxButtons.YesNo);

                if (result == DialogResult.No)
                {
                    return;
                }

                if (result == DialogResult.Yes)
                {
                    Part tempAssociatedPart = (Part)dgvModParts.CurrentRow.DataBoundItem;
                    tempAssociatedParts.Add(tempAssociatedPart);
                    foreach (var part in tempAssociatedParts)
                    {
                        if (Equals(part.PartID, tempAssociatedPart))
                        {
                            MessageBox.Show("This part is already associated with this product.");
                            return;
                        }
                    }
                }
            }
        }


        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvModAssociatedParts.CurrentRow == null || !dgvModAssociatedParts.CurrentRow.Selected)
            {
                MessageBox.Show("Error: You must select a part to delete.");
            }
            else
            {
                var result = MessageBox.Show("Are you sure you want to delete this part? This cannot be undone.",
                    "Confirmation", MessageBoxButtons.YesNo);

                if (result == DialogResult.No)
                {
                    return;
                }

                if (result == DialogResult.Yes)
                {
                    Part currentPart = (Part)dgvModAssociatedParts.CurrentRow.DataBoundItem;
                    int productID = int.Parse(tbIDNum.Text);
                    Product currentProd = Inventory.LookupProduct(productID);
                    currentProd.RemoveAssociatedPart(currentPart.PartID);

                    foreach (DataGridViewRow part in dgvModAssociatedParts.SelectedRows)
                    {
                        dgvModAssociatedParts.Rows.RemoveAt(part.Index);
                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //Display error message when defaults are unused by the user
            //Comp Name goes back to "Comp Name" when clicking save and displays an error when a new string is entered
            if (tbName.Text.Contains("Part Name") || tbInv.Text.Contains("Inv") ||
                tbPriceCost.Text.Contains("Price/Cost") ||
                tbMax.Text.Contains("Max") || tbMin.Text.Contains("Min"))

            {
                MessageBox.Show("Error: One or more field values are missing. Please try again.");
                return;
            }

            //Random Number Generator 
            var rnd = new Random();
            var num = rnd.Next(10000, 99999);


            //Initial Variables

            var name = tbName.Text;
            int inStock;
            decimal price;
            int max;
            int min;
            int n;
            decimal x;

            //Try Variables
            var isInv = int.TryParse(tbInv.Text, out n);
            var isPrice = decimal.TryParse(tbPriceCost.Text, out x);
            var isMax = int.TryParse(tbMax.Text, out n);
            var isMin = int.TryParse(tbMin.Text, out n);
            ;

            if (isInv == true)
            {
                inStock = int.Parse(tbInv.Text);
            }
            else
            {
                MessageBox.Show("Error: Inventory value must be a numeric value.");
                return;
            }

            if (isPrice == true)
            {
                price = decimal.Parse(tbPriceCost.Text);
            }
            else
            {
                MessageBox.Show("Error: Price/Cost value must be a numeric value.");
                return;
            }

            if (isMax == true)
            {
                max = int.Parse(tbMax.Text);
            }
            else
            {
                MessageBox.Show("Error: Max value must be a numeric value.");
                return;
            }

            if (isMin == true)
            {
                min = int.Parse(tbMin.Text);
            }
            else
            {
                MessageBox.Show("Error: Min value must be a numeric value.");
                return;
            }


            if (max < min)
            {
                MessageBox.Show("Error: Maximum value cannot be less than the minimum value.");
                return;
            }

            if (min <= 0)
            {
                MessageBox.Show("Error: Minimum value cannot be less than or equal to zero.");
                return;
            }

            if (inStock > max || inStock < min)
            {
                MessageBox.Show(
                    "Error: Inventory must be between the minimum and maximum amount of inventory.");
                return;
            }

            //Add exception if there's an empty associated parts table then throw message and return
            //if (dgvModAssociatedParts.RowCount == 0)
            //{
            //    MessageBox.Show("Error: You must add a part to be associated with this product.");
            //    return;
            //}

            int idNum = int.Parse(tbIDNum.Text);
            Product productUpdate = new Product(idNum, name, inStock, price, min, max);
            foreach (Part updatePart in tempAssociatedParts)
            {
                productUpdate.AddAssociatedPart(updatePart);
            }
            Inventory.UpdateProduct(idNum, productUpdate);
            this.Close();
        }


        //Cancel Button
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

    
