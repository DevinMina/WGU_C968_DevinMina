﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DevinMina_C968
{
    public partial class AddPart : Form
    {
        public AddPart()
        {
            InitializeComponent();
        }


        //In-House Radio - Default
        private void radBtnInHouse_CheckedChanged(object sender, EventArgs e)
        {
            labelCompanyName.Text = "Machine ID";
            if (radBtnInHouse.Checked == true)
            {
                tbMachID_CompNm.Text = "Machine ID";
                tbMachID_CompNm.ForeColor = Color.DimGray;
            }
        }

        //Outsourced Radio
        private void radBtnOutsourced_CheckedChanged(object sender, EventArgs e)
        {
            labelCompanyName.Text = "Company Name";
            if (radBtnOutsourced.Checked == true)
            {
                tbMachID_CompNm.Text = "Comp Name";
                tbMachID_CompNm.ForeColor = Color.DimGray;
            }
        }

        //Name TextBox - Enter/Leave
        private void tbName_Enter(object sender, EventArgs e)
        {
            if (tbName.Text.Contains("Part Name"))
            {
                tbName.Text = "";
                tbName.ForeColor = Color.Black;
            }
        }

        private void tbName_Leave(object sender, EventArgs e)
        {
            if (tbName.Text == "")
            {
                tbName.Text = "Part Name";
                tbName.ForeColor = Color.DimGray;
            }
        }

        //Inv TextBox - Enter/Leave
        private void tbInv_Enter(object sender, EventArgs e)
        {
            if (tbInv.Text.Contains("Inv"))
            {
                tbInv.Text = "";
                tbInv.ForeColor = Color.Black;
            }
        }

        private void tbInv_Leave(object sender, EventArgs e)
        {
            if (tbInv.Text == "")
            {
                tbInv.Text = "Inv";
                tbInv.ForeColor = Color.DimGray;
            }
        }

        //Price/Cost TextBox - Enter/Leave
        private void tbPriceCost_Enter(object sender, EventArgs e)
        {
            if (tbPriceCost.Text.Contains("Price/Cost"))
            {
                tbPriceCost.Text = "";
                tbPriceCost.ForeColor = Color.Black;
            }
        }

        private void tbPriceCost_Leave(object sender, EventArgs e)
        {
            if (tbPriceCost.Text == "")
            {
                tbPriceCost.Text = "Price/Cost";
                tbPriceCost.ForeColor = Color.DimGray;
            }
        }

        //Max TextBox - Enter/Leave
        private void tbMax_Enter(object sender, EventArgs e)
        {
            if (tbMax.Text.Contains("Max"))
            {
                tbMax.Text = "";
                tbMax.ForeColor = Color.Black;
            }
        }

        private void tbMax_Leave(object sender, EventArgs e)
        {
            if (tbMax.Text == "")
            {
                tbMax.Text = "Max";
                tbMax.ForeColor = Color.DimGray;
            }
        }

        //Min TextBox - Enter/Leave
        private void tbMin_Enter(object sender, EventArgs e)
        {
            if (tbMin.Text.Contains("Min"))
            {
                tbMin.Text = "";
                tbMin.ForeColor = Color.Black;
            }
        }

        private void tbMin_Leave(object sender, EventArgs e)
        {
            if (tbMin.Text == "")
            {
                tbMin.Text = "Min";
                tbMin.ForeColor = Color.DimGray;
            }
        }

        //CompName_&_MachineID TextBox - Enter/Leave
        private void tbMachID_CompNm_Enter(object sender, EventArgs e)
        {
            if (radBtnInHouse.Checked)
            {
                if (tbMachID_CompNm.Text.Contains("Machine ID") || tbMachID_CompNm.Text.Contains("Comp Name"))
                {
                    tbMachID_CompNm.Text = "";
                    tbMachID_CompNm.ForeColor = Color.Black;
                }
            }
            else if (radBtnOutsourced.Checked)
            {
                if (tbMachID_CompNm.Text.Contains("Comp Name"))
                {
                    tbMachID_CompNm.Text = "";
                    tbMachID_CompNm.ForeColor = Color.Black;
                }
            }
        }

        private void tbMachID_CompNm_Leave(object sender, EventArgs e)
        {
            if (radBtnInHouse.Checked)
            {
                if (tbMachID_CompNm.Text == "")
                {
                    tbMachID_CompNm.Text = "Machine ID";
                    tbMachID_CompNm.ForeColor = Color.DimGray;
                }
            }
            else if (radBtnOutsourced.Checked)
            {
                if (tbMachID_CompNm.Text == "")
                {
                    tbMachID_CompNm.Text = "Comp Name";
                    tbMachID_CompNm.ForeColor = Color.DimGray;
                }
            }
        }

        //Cancel Button
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        //Save Button
        private void btnSave_Click(object sender, EventArgs e)
        {
            //Display error message when defaults are unused by the user
            //Comp Name goes back to "Comp Name" when clicking save and displays an error when a new string is entered
            if (tbName.Text.Contains("Part Name") || tbInv.Text.Contains("Inv") ||
                tbPriceCost.Text.Contains("Price/Cost") ||
                tbMax.Text.Contains("Max") || tbMin.Text.Contains("Min") ||
                tbMachID_CompNm.Text.Contains("Machine ID, Comp Name") ||
                tbMachID_CompNm.Text.Contains("Machine ID") ||
                (radBtnOutsourced.Checked && tbMachID_CompNm.Text == "Comp Name"))

            {
                MessageBox.Show("Error: One or more field values are missing. Please try again.");
                return;
            }

            //Random Number Generator 
            var rnd = new Random();
            var num = rnd.Next(10000, 99999);


            //Initial Variables
            var name = tbName.Text;
            int inStock;
            decimal price;
            int max;
            int min;
            int machineID;
            var compName = tbMachID_CompNm.Text;
            int n;
            decimal x;

            //Try Variables
            var isInv = int.TryParse(tbInv.Text, out n);
            var isPrice = decimal.TryParse(tbPriceCost.Text, out x);
            var isMax = int.TryParse(tbMax.Text, out n);
            var isMin = int.TryParse(tbMin.Text, out n);
            var isMac = int.TryParse(tbMachID_CompNm.Text, out n);

            if (isInv == true)
            {
                inStock = int.Parse(tbInv.Text);
            }
            else
            {
                MessageBox.Show("Error: Inventory value must be a numeric value.");
                return;
            }

            if (isPrice == true)
            {
                price = decimal.Parse(tbPriceCost.Text);
            }
            else
            {
                MessageBox.Show("Error: Price/Cost value must be a numeric value.");
                return;
            }

            if (isMax == true)
            {
                max = int.Parse(tbMax.Text);
            }
            else
            {
                MessageBox.Show("Error: Max value must be a numeric value.");
                return;
            }

            if (isMin == true)
            {
                min = int.Parse(tbMin.Text);
            }
            else
            {
                MessageBox.Show("Error: Min value must be a numeric value.");
                return;
            }


            if (max < min)
            {
                MessageBox.Show("Error: Maximum value cannot be less than the minimum value.");
                return;
            }

            if (min <= 0)
            {
                MessageBox.Show("Error: Minimum value cannot be less than or equal to zero.");
                return;
            }

            if (inStock > max || inStock < min)
            {
                MessageBox.Show(
                    "Error: Inventory must be between the minimum and maximum amount of inventory.");
                return;
            }

            if (radBtnInHouse.Checked)
            {
                if (isMac == true)
                {
                    machineID = int.Parse(tbMachID_CompNm.Text);
                }
                else
                {
                    MessageBox.Show("Error: Machine ID value must be a numeric value.");
                    return;
                }

                InHouse inHousePart =
                    new InHouse(num, name, inStock, price, min, max, machineID);
                Inventory.AddPart(inHousePart);
            }
            else
            {
                Outsourced outsourcedPart =
                    new Outsourced(num, name, inStock, price, min, max, compName);
                Inventory.AddPart(outsourcedPart);
            }

            this.Close();
        }
    }
}